
#define SECRET_SSID "***************"       // dein WLAN-Name
#define SECRET_PASS "***************"  // dein WLAN-Passwort